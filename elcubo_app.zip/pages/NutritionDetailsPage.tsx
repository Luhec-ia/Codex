
import React, { useState, useCallback } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Select from '../components/ui/Select';
import Card from '../components/ui/Card';
import Spinner from '../components/ui/Spinner';
import { generateJson, generateText } from '../services/geminiService';
import { Recipe as RecipeType, GroundingMetadata } from '../types';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';
import { SearchIcon }  from '../components/icons';

interface MacroCalculationResult {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  advice?: string;
}

const NutritionDetailsPage: React.FC = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('male');
  const [activityLevel, setActivityLevel] = useState('sedentary');
  const [macroResult, setMacroResult] = useState<MacroCalculationResult | null>(null);
  const [isCalculatingMacros, setIsCalculatingMacros] = useState(false);

  const [recipeQuery, setRecipeQuery] = useState('');
  const [generatedRecipe, setGeneratedRecipe] = useState<RecipeType | null>(null);
  const [recipeGrounding, setRecipeGrounding] = useState<GroundingMetadata | undefined>();
  const [isFindingRecipe, setIsFindingRecipe] = useState(false);
  const [recipeError, setRecipeError] = useState<string | null>(null);
  const [macroError, setMacroError] = useState<string | null>(null);


  const handleMacroCalculate = useCallback(async () => {
    if (!weight || !height || !age) {
      setMacroError("Por favor, complete todos los campos para calcular macros.");
      return;
    }
    setMacroError(null);
    setIsCalculatingMacros(true);
    setMacroResult(null);
    const prompt = `Calculate estimated daily caloric and macronutrient needs for a person with the following details:
    Weight: ${weight} kg
    Height: ${height} cm
    Age: ${age} years
    Gender: ${gender}
    Activity Level: ${activityLevel} (options: sedentary, light, moderate, active, very_active)
    
    Return the result as a JSON object with keys: "calories" (number), "protein" (number, in grams), "carbs" (number, in grams), "fat" (number, in grams), and an optional "advice" (string, brief dietary tip).
    Example: {"calories": 2000, "protein": 150, "carbs": 200, "fat": 60, "advice": "Focus on whole foods."}`;

    try {
      const result = await generateJson<MacroCalculationResult>(prompt, "You are a nutrition calculator assistant.");
      setMacroResult(result);
    } catch (error) {
      console.error("Error calculating macros:", error);
      setMacroError("No se pudieron calcular los macros. Inténtalo de nuevo.");
    } finally {
      setIsCalculatingMacros(false);
    }
  }, [weight, height, age, gender, activityLevel]);

  const handleFindRecipe = useCallback(async () => {
    if (!recipeQuery.trim()) {
      setRecipeError("Por favor, ingresa ingredientes o tipo de receta.");
      return;
    }
    setRecipeError(null);
    setIsFindingRecipe(true);
    setGeneratedRecipe(null);
    setRecipeGrounding(undefined);
    const prompt = `Generate a healthy recipe based on the following query: "${recipeQuery}". 
    Include a name, a short description, a list of ingredients, and step-by-step instructions.
    You can optionally include an image URL from picsum.photos like "https://picsum.photos/seed/${recipeQuery.replace(/\s+/g, '_')}/400/300".
    Return as JSON: {"name": "Recipe Name", "description": "...", "ingredients": ["...", "..."], "instructions": "...", "imageUrl": "..."}`;
    
    try {
      const result = await generateJson<RecipeType>(prompt, "You are a helpful recipe assistant specializing in healthy meals.");
      setGeneratedRecipe(result);
       // If you want to use Google Search to find related info, or if Gemini provides grounding metadata
      const { text: _, groundingMetadata } = await generateText(`Find information about ${recipeQuery} recipe benefits`, undefined, true);
      setRecipeGrounding(groundingMetadata);
    } catch (error) {
      console.error("Error finding recipe:", error);
      setRecipeError("No se pudo encontrar la receta. Inténtalo de nuevo.");
    } finally {
      setIsFindingRecipe(false);
    }
  }, [recipeQuery]);

  const activityLevels = [
    { value: 'sedentary', label: 'Sedentario (poco o nada de ejercicio)' },
    { value: 'light', label: 'Ligero (ejercicio 1-3 días/semana)' },
    { value: 'moderate', label: 'Moderado (ejercicio 3-5 días/semana)' },
    { value: 'active', label: 'Activo (ejercicio 6-7 días/semana)' },
    { value: 'very_active', label: 'Muy activo (ejercicio intenso diario o trabajo físico)' },
  ];

  return (
    <PageWrapper title="Nutrición Avanzada" backPath="/nutrition">
      <div className="space-y-12">
        {/* Recipe Finder */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-emerald-400 mb-4">Encontrar Receta</h2>
          <div className="space-y-4">
            <Input
              Icon={SearchIcon}
              type="text"
              placeholder="Ej: 'pollo y brócoli', 'ensalada vegana alta en proteínas'"
              value={recipeQuery}
              onChange={(e) => setRecipeQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleFindRecipe()}
            />
            <Button onClick={handleFindRecipe} isLoading={isFindingRecipe} className="w-full md:w-auto">
              Buscar Receta
            </Button>
          </div>
          {recipeError && <p className="mt-2 text-sm text-red-400">{recipeError}</p>}
          {isFindingRecipe && <Spinner className="mt-4" />}
          {generatedRecipe && (
            <Card className="mt-6 p-4 bg-slate-700/50">
              <h3 className="text-xl font-semibold text-emerald-300 mb-2">{generatedRecipe.name}</h3>
              {generatedRecipe.imageUrl && (
                <img src={generatedRecipe.imageUrl} alt={generatedRecipe.name} className="rounded-lg mb-3 w-full max-w-sm aspect-video object-cover mx-auto" />
              )}
              <p className="text-slate-300 mb-3 text-sm">{generatedRecipe.description}</p>
              <div className="mb-3">
                <h4 className="font-medium text-slate-200 mb-1">Ingredientes:</h4>
                <ul className="list-disc list-inside text-slate-300 space-y-0.5 text-sm">
                  {generatedRecipe.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-slate-200 mb-1">Instrucciones:</h4>
                <GeminiResponseDisplay text={generatedRecipe.instructions} groundingMetadata={recipeGrounding} className="bg-transparent shadow-none p-0" />
              </div>
            </Card>
          )}
        </Card>

        {/* Macro Calculator */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-emerald-400 mb-6">Calculadora de Macros</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Input label="Peso (kg)" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="Ej: 70" />
            <Input label="Altura (cm)" type="number" value={height} onChange={(e) => setHeight(e.target.value)} placeholder="Ej: 175" />
            <Input label="Edad (años)" type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="Ej: 30" />
            <Select
              label="Género"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
              options={[
                { value: 'male', label: 'Masculino' },
                { value: 'female', label: 'Femenino' },
              ]}
            />
            <div className="md:col-span-2">
              <Select
                label="Nivel de Actividad"
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value)}
                options={activityLevels}
              />
            </div>
          </div>
          <Button onClick={handleMacroCalculate} isLoading={isCalculatingMacros} className="w-full md:w-auto">
            Calcular Macros
          </Button>
          {macroError && <p className="mt-2 text-sm text-red-400">{macroError}</p>}
          {isCalculatingMacros && <Spinner className="mt-4" />}
          {macroResult && (
            <Card className="mt-6 p-4 bg-slate-700/50">
              <h3 className="text-xl font-semibold text-emerald-300 mb-3">Resultados Estimados:</h3>
              <ul className="space-y-1.5 text-slate-200">
                <li>Calorías: <span className="font-medium text-emerald-400">{macroResult.calories.toFixed(0)} kcal</span></li>
                <li>Proteínas: <span className="font-medium text-emerald-400">{macroResult.protein.toFixed(0)} g</span></li>
                <li>Carbohidratos: <span className="font-medium text-emerald-400">{macroResult.carbs.toFixed(0)} g</span></li>
                <li>Grasas: <span className="font-medium text-emerald-400">{macroResult.fat.toFixed(0)} g</span></li>
              </ul>
              {macroResult.advice && (
                <p className="mt-3 text-sm text-slate-300 italic border-t border-slate-600 pt-2">Consejo: {macroResult.advice}</p>
              )}
            </Card>
          )}
        </Card>
      </div>
    </PageWrapper>
  );
};

export default NutritionDetailsPage;
