import React from 'react';
import { Section, SectionConfig } from './types';
import { 
  AppleIcon, 
  DumbbellIcon, 
  BrainIcon, 
  GamepadIcon, 
  LeafIcon,
  TshirtIcon,
  PlaneIcon
} from './components/icons';

export const APP_NAME = "CuboVerse Wellness Hub";

export const SECTIONS: Record<Section, SectionConfig> = {
  [Section.Nutrition]: {
    id: Section.Nutrition,
    name: "Alimentación",
    Icon: AppleIcon,
    description: "Consejos para una alimentación saludable, rica y fácil.",
    themeColor: "text-emerald-400",
    darkThemeColor: "text-emerald-600",
    detailPath: "/nutrition/details",
  },
  [Section.Fitness]: {
    id: Section.Fitness,
    name: "Fitness",
    Icon: DumbbellIcon,
    description: "Eleva tu jornada de fitness con retos y rutinas.",
    themeColor: "text-sky-400",
    darkThemeColor: "text-sky-600",
    detailPath: "/fitness/details",
  },
  [Section.Mind]: {
    id: Section.Mind,
    name: "Mente",
    Icon: BrainIcon,
    description: "Expande tu mente y mejora tu productividad.",
    themeColor: "text-purple-400",
    darkThemeColor: "text-purple-600",
    detailPath: "/mind/details", 
  },
  [Section.Entertainment]: {
    id: Section.Entertainment,
    name: "Entretenimiento",
    Icon: GamepadIcon,
    description: "Descubre mini juegos y próximos lanzamientos.",
    themeColor: "text-rose-400",
    darkThemeColor: "text-rose-600",
    detailPath: "/entertainment/details",
  },
  [Section.Wellness]: {
    id: Section.Wellness,
    name: "Bienestar",
    Icon: LeafIcon,
    description: "Encuentra tu paz interior y equilibra tus emociones.",
    themeColor: "text-lime-400",
    darkThemeColor: "text-lime-600",
    detailPath: "/wellness/details",
  },
  [Section.Style]: {
    id: Section.Style,
    name: "Estilo",
    Icon: TshirtIcon,
    description: "Define tu estilo y exprésate con confianza.",
    themeColor: "text-pink-400",
    darkThemeColor: "text-pink-600",
    detailPath: "/style/details", 
  },
  [Section.Travel]: {
    id: Section.Travel,
    name: "Viajes",
    Icon: PlaneIcon,
    description: "Explora el mundo y planifica tu próxima aventura.",
    themeColor: "text-indigo-400",
    darkThemeColor: "text-indigo-600",
    detailPath: "/travel/details",
  }
};

export const DEFAULT_SECTION = Section.Nutrition;

// Gemini API related constants
export const GEMINI_API_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';
export const GEMINI_API_MODEL_IMAGE = 'imagen-3.0-generate-002';
export const API_KEY = process.env.API_KEY;

// UI constants
export const MAIN_ACCENT_COLOR_BG = "bg-emerald-500";
export const MAIN_ACCENT_COLOR_TEXT = "text-emerald-500";
export const MAIN_ACCENT_COLOR_BORDER = "border-emerald-500";

export const FLOATING_ACTION_BUTTON_COLOR = "bg-green-500 hover:bg-green-600";