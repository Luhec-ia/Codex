
import React, { useState, useEffect, useCallback } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import { generateJson, generateText } from '../services/geminiService';
import { WorkoutRoutine, GroundingMetadata } from '../types';
import { CheckIcon } from '../components/icons';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';

interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  points: number;
  imageUrl: string;
}

const progressData = [
  { name: 'W1', completion: 75 },
  { name: 'W2', completion: 80 },
  { name: 'W3', completion: 70 },
  { name: 'W4', completion: 85 },
  { name: 'W5', completion: 90 },
];

const initialWorkoutRoutines: WorkoutRoutine[] = [
  { id: 'strength1', name: 'Entrenamiento de Fuerza', description: 'Construye músculo y resistencia.', imageUrl: 'https://picsum.photos/seed/strength/400/300', category: 'Fuerza' },
  { id: 'cardio1', name: 'Explosión Cardiovascular', description: 'Aumenta tu ritmo cardíaco.', imageUrl: 'https://picsum.photos/seed/cardio/400/300', category: 'Cardio' },
  { id: 'yoga1', name: 'Flujo de Yoga', description: 'Encuentra equilibrio y flexibilidad.', imageUrl: 'https://picsum.photos/seed/yoga/400/300', category: 'Flexibilidad' },
];

const FitnessDetailsPage: React.FC = () => {
  const [dailyChallenge, setDailyChallenge] = useState<DailyChallenge | null>(null);
  const [workoutRoutines, setWorkoutRoutines] = useState<WorkoutRoutine[]>(initialWorkoutRoutines);
  const [isLoadingChallenge, setIsLoadingChallenge] = useState(true);
  const [isLoadingRoutines, setIsLoadingRoutines] = useState(false);
  const [selectedRoutine, setSelectedRoutine] = useState<WorkoutRoutine | null>(null);
  const [routineDetails, setRoutineDetails] = useState<string | null>(null);
  const [routineGrounding, setRoutineGrounding] = useState<GroundingMetadata | undefined>();
  const [isLoadingRoutineDetails, setIsLoadingRoutineDetails] = useState(false);


  const fetchDailyChallenge = useCallback(async () => {
    setIsLoadingChallenge(true);
    const prompt = `Generate a fun and engaging daily fitness challenge. 
    Return as JSON: {"id": "challenge_today", "title": "Challenge Title", "description": "Brief description", "points": 50, "imageUrl": "https://picsum.photos/seed/challenge/400/200"}`;
    try {
      const challenge = await generateJson<DailyChallenge>(prompt, "You are a fitness challenge creator.");
      setDailyChallenge(challenge);
    } catch (error) {
      console.error("Error fetching daily challenge:", error);
      setDailyChallenge({ // Fallback challenge
        id: 'fallback_challenge',
        title: '100 Flexiones Hoy',
        description: 'Completa 100 flexiones para ganar 50 puntos.',
        points: 50,
        imageUrl: 'https://picsum.photos/seed/pushups/400/200'
      });
    } finally {
      setIsLoadingChallenge(false);
    }
  }, []);

  const fetchWorkoutRoutines = useCallback(async () => {
    setIsLoadingRoutines(true);
    const prompt = `Generate 3 diverse workout routines (e.g., strength, cardio, flexibility).
    For each routine, provide id (string), name (string), description (string), category (string), and an imageUrl ("https://picsum.photos/seed/UNIQUE_NAME/400/300").
    Return as a JSON array of objects.`;
    try {
      const routines = await generateJson<WorkoutRoutine[]>(prompt, "You are a workout routine planner.");
      if (routines && routines.length > 0) {
        setWorkoutRoutines(routines);
      } else {
        setWorkoutRoutines(initialWorkoutRoutines); // Fallback
      }
    } catch (error) {
      console.error("Error fetching workout routines:", error);
      setWorkoutRoutines(initialWorkoutRoutines); // Fallback
    } finally {
      setIsLoadingRoutines(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  useEffect(() => {
    fetchDailyChallenge();
    // fetchWorkoutRoutines(); // Optionally fetch dynamic routines
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectRoutine = async (routine: WorkoutRoutine) => {
    setSelectedRoutine(routine);
    setRoutineDetails(null);
    setRoutineGrounding(undefined);
    setIsLoadingRoutineDetails(true);
    const prompt = `Provide a detailed workout plan for "${routine.name}" which is a ${routine.category} routine. Include exercises, sets, reps, and rest times. Mention any necessary equipment.`;
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a detailed fitness trainer.", true);
      setRoutineDetails(text);
      setRoutineGrounding(groundingMetadata);
    } catch (error) {
      console.error("Error fetching routine details:", error);
      setRoutineDetails("No se pudieron cargar los detalles de la rutina.");
    } finally {
      setIsLoadingRoutineDetails(false);
    }
  };


  return (
    <PageWrapper title="Tu Espacio Fitness" backPath="/fitness">
      <div className="space-y-8">
        {/* Hero Section / Daily Challenge */}
        {isLoadingChallenge && <Spinner />}
        {dailyChallenge && (
          <Card className="p-6 bg-gradient-to-r from-sky-600/80 to-cyan-600/80 text-white shadow-cyan-500/30">
             <div className="flex flex-col md:flex-row gap-6 items-center">
              <img src={dailyChallenge.imageUrl} alt={dailyChallenge.title} className="w-full md:w-1/3 h-auto rounded-lg object-cover aspect-video" />
              <div className="flex-1">
                <h2 className="text-sm uppercase tracking-wider mb-1 text-sky-200">Reto Diario</h2>
                <h3 className="text-3xl font-bold mb-2">{dailyChallenge.title}</h3>
                <p className="text-sky-100 mb-3">{dailyChallenge.description}</p>
                <p className="mb-4 font-semibold">Gana {dailyChallenge.points} puntos!</p>
                <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border border-white/30">
                  <CheckIcon className="w-5 h-5 mr-2"/> Empezar Reto
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Workout Routines */}
        <section>
          <h2 className="text-2xl font-semibold text-sky-400 mb-4">Rutinas de Ejercicio</h2>
          {isLoadingRoutines && <Spinner />}
          {!isLoadingRoutines && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {workoutRoutines.map((routine) => (
                <Card key={routine.id} className="flex flex-col" hoverEffect>
                  <img src={routine.imageUrl} alt={routine.name} className="w-full h-48 object-cover" />
                  <div className="p-4 flex flex-col flex-grow">
                    <h3 className="text-xl font-semibold text-sky-300 mb-1">{routine.name}</h3>
                    <p className="text-slate-300 text-sm mb-3 flex-grow">{routine.description}</p>
                    <Button variant="primary" size="sm" onClick={() => handleSelectRoutine(routine)} className="w-full mt-auto bg-sky-500 hover:bg-sky-600">
                      Ver Detalles
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Selected Routine Details */}
        {selectedRoutine && (
          <Card className="p-6 mt-6">
            <h3 className="text-2xl font-semibold text-sky-400 mb-3">Detalles de: {selectedRoutine.name}</h3>
            {isLoadingRoutineDetails && <Spinner />}
            {routineDetails && <GeminiResponseDisplay text={routineDetails} groundingMetadata={routineGrounding} />}
          </Card>
        )}
        

        {/* Progress Tracking */}
        <section>
          <h2 className="text-2xl font-semibold text-sky-400 mb-4">Seguimiento de Progreso</h2>
          <Card className="p-4 md:p-6">
            <div className="flex justify-between items-baseline mb-2">
              <h3 className="text-lg font-medium text-slate-200">Completitud de Entrenamientos</h3>
              <p className="text-3xl font-bold text-sky-400">85% <span className="text-sm font-normal text-green-400 ml-1">+10%</span></p>
            </div>
            <p className="text-xs text-slate-400 mb-4">Últimos 30 Días</p>
            <div style={{ width: '100%', height: 300 }}>
              <ResponsiveContainer>
                <LineChart data={progressData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} stroke="#4A5568" />
                  <XAxis dataKey="name" tick={{ fill: '#A0AEC0' }} stroke="#4A5568" />
                  <YAxis tick={{ fill: '#A0AEC0' }} stroke="#4A5568" unit="%" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1A202C', border: '1px solid #2D3748', borderRadius: '0.5rem' }}
                    labelStyle={{ color: '#E2E8F0' }}
                    itemStyle={{ color: '#38BDF8' }}
                  />
                  <Legend wrapperStyle={{ color: '#A0AEC0' }}/>
                  <Line type="monotone" dataKey="completion" stroke="#38BDF8" strokeWidth={2} dot={{ r: 4, fill: '#38BDF8' }} activeDot={{ r: 6 }} name="Completitud"/>
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </section>
      </div>
    </PageWrapper>
  );
};

export default FitnessDetailsPage;
