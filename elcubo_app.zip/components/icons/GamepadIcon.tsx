
import React from 'react';

const GamepadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h2.25V1.5z" />
    <path d="M15.75 1.5h-2.25v21h2.25A2.25 2.25 0 0018 20.25V3.75A2.25 2.25 0 0015.75 1.5z" />
    <path fillRule="evenodd" d="M12 6.75A5.25 5.25 0 006.75 12H3a.75.75 0 000 1.5h3.75a5.25 5.25 0 0010.5 0H21a.75.75 0 000-1.5h-3.75A5.25 5.25 0 0012 6.75zM8.25 12.75a.75.75 0 01.75-.75H10.5a.75.75 0 01.75.75v1.5a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v-1.5zM13.5 12.75a.75.75 0 01.75-.75h1.5a.75.75 0 01.75.75v1.5a.75.75 0 01-.75.75h-1.5a.75.75 0 01-.75-.75v-1.5z" clipRule="evenodd" />
  </svg>
);
export default GamepadIcon;
