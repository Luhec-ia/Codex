
import React, { useState, useEffect, useCallback } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import { generateText, generateJson } from '../services/geminiService';
import { WellnessActivity, GroundingMetadata } from '../types';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';

const initialWellnessActivities: WellnessActivity[] = [
  { id: 'meditation1', name: 'Meditación Guiada', description: 'Encuentra tu paz interior con esta sesión de 5 minutos.', duration: '5 min', imageUrl: 'https://picsum.photos/seed/meditation_calm/400/250' },
  { id: 'moodtracker1', name: 'Rastreador de Ánimo', description: 'Reflexiona sobre tus emociones y lleva un seguimiento diario.', imageUrl: 'https://picsum.photos/seed/mood_journal/400/250' },
  { id: 'quote1', name: 'Cita Motivacional', description: 'Empieza tu día con una dosis de inspiración.', imageUrl: 'https://picsum.photos/seed/inspiration_quote/400/250' },
];

const WellnessDetailsPage: React.FC = () => {
  const [activities, setActivities] = useState<WellnessActivity[]>(initialWellnessActivities);
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});
  const [activityContent, setActivityContent] = useState<Record<string, { text: string, grounding?: GroundingMetadata }>>({});

  const fetchActivityContent = useCallback(async (activity: WellnessActivity) => {
    setIsLoading(prev => ({ ...prev, [activity.id]: true }));
    setActivityContent(prev => ({ ...prev, [activity.id]: {text: ''} }));

    let prompt = "";
    let systemInstruction = "You are a wellness assistant.";
    let useSearch = false;

    if (activity.name.toLowerCase().includes('meditación')) {
      prompt = `Generate a short guided meditation script (around ${activity.duration || '5 minutes'} long). Focus on mindfulness and relaxation.`;
      systemInstruction = "You are a calm and soothing meditation guide.";
    } else if (activity.name.toLowerCase().includes('ánimo')) {
      prompt = `Provide 3 thoughtful journal prompts for mood tracking and self-reflection.`;
      systemInstruction = "You are a supportive journaling companion.";
    } else if (activity.name.toLowerCase().includes('cita')) {
      prompt = `Generate an inspiring and original motivational quote. Keep it concise.`;
      systemInstruction = "You are a source of daily inspiration.";
      useSearch = true; // For quotes, it might be good to see if Gemini can ground it or provide context.
    } else {
      prompt = `Provide helpful content related to "${activity.name}".`;
    }
    
    if (!prompt) {
         setIsLoading(prev => ({ ...prev, [activity.id]: false }));
         return;
    }

    try {
      const { text, groundingMetadata } = await generateText(prompt, systemInstruction, useSearch);
      setActivityContent(prev => ({ ...prev, [activity.id]: { text, grounding: groundingMetadata } }));
    } catch (error) {
      console.error(`Error fetching content for ${activity.name}:`, error);
      setActivityContent(prev => ({ ...prev, [activity.id]: {text: `No se pudo cargar el contenido para ${activity.name}.`} }));
    } finally {
      setIsLoading(prev => ({ ...prev, [activity.id]: false }));
    }
  }, []);
  
  // Optionally fetch dynamic activities on load
  // useEffect(() => { /* fetch initial activities */ }, []);

  return (
    <PageWrapper title="Tu Espacio de Bienestar" backPath="/wellness">
      <div className="space-y-6">
        {activities.map(activity => (
          <Card key={activity.id} className="overflow-hidden">
            <img src={activity.imageUrl} alt={activity.name} className="w-full h-56 object-cover" />
            <div className="p-5">
              <h3 className="text-xl font-semibold text-lime-300 mb-1">{activity.name}</h3>
              <p className="text-slate-300 text-sm mb-1">{activity.description}</p>
              {activity.duration && <p className="text-xs text-slate-400 mb-3">Duración: {activity.duration}</p>}
              
              {!activityContent[activity.id]?.text && !isLoading[activity.id] && (
                <Button 
                  variant="primary" 
                  size="sm" 
                  onClick={() => fetchActivityContent(activity)}
                  className="mt-2 bg-lime-500 hover:bg-lime-600"
                >
                  {activity.name.toLowerCase().includes('cita') ? 'Generar Cita' : 'Empezar Actividad'}
                </Button>
              )}

              {isLoading[activity.id] && <Spinner size="sm" className="mt-3" />}
              
              {activityContent[activity.id]?.text && !isLoading[activity.id] && (
                <div className="mt-3 pt-3 border-t border-slate-700">
                   <GeminiResponseDisplay 
                    text={activityContent[activity.id].text} 
                    groundingMetadata={activityContent[activity.id].grounding}
                    className="bg-slate-800/50 text-sm"
                  />
                  <Button 
                    variant="secondary" 
                    size="sm" 
                    onClick={() => fetchActivityContent(activity)} 
                    className="mt-3 text-xs"
                    isLoading={isLoading[activity.id]}
                  >
                    {activity.name.toLowerCase().includes('cita') ? 'Generar Otra Cita' : 'Recargar'}
                  </Button>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>
    </PageWrapper>
  );
};

export default WellnessDetailsPage;
