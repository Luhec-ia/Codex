import React, { useState, useCallback, useEffect } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Spinner from '../components/ui/Spinner';
import { generateText } from '../services/geminiService';
import { GroundingMetadata } from '../types';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';
import { SearchIcon } from '../components/icons';

const StyleDetailsPage: React.FC = () => {
  const [styleTip, setStyleTip] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingStyleTip, setIsLoadingStyleTip] = useState(false);

  const [occasionQuery, setOccasionQuery] = useState('');
  const [outfitIdea, setOutfitIdea] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingOutfitIdea, setIsLoadingOutfitIdea] = useState(false);

  const [colorQuery, setColorQuery] = useState('');
  const [colorPalette, setColorPalette] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingColorPalette, setIsLoadingColorPalette] = useState(false);
  
  const [error, setError] = useState<string | null>(null);

  const fetchStyleTip = useCallback(async () => {
    setIsLoadingStyleTip(true);
    setStyleTip(null);
    setError(null);
    const prompt = "Generate a unique and practical style tip of the day. Keep it concise and inspiring.";
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a trend-savvy fashion advisor.");
      setStyleTip({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching style tip:", err);
      setError("No se pudo generar el consejo de estilo. Inténtalo de nuevo.");
    } finally {
      setIsLoadingStyleTip(false);
    }
  }, []);

  const fetchOutfitIdea = useCallback(async () => {
    if (!occasionQuery.trim()) {
      setError("Por favor, ingresa una ocasión.");
      return;
    }
    setIsLoadingOutfitIdea(true);
    setOutfitIdea(null);
    setError(null);
    const prompt = `Suggest a stylish outfit idea for the following occasion: "${occasionQuery}". Describe the key pieces and the overall look. Mention any specific style (e.g., bohemian, classic, edgy) if applicable. Use Google Search for current fashion trends if helpful.`;
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a fashion stylist providing outfit suggestions.", true);
      setOutfitIdea({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching outfit idea:", err);
      setError("No se pudo generar la idea de atuendo. Inténtalo de nuevo.");
    } finally {
      setIsLoadingOutfitIdea(false);
    }
  }, [occasionQuery]);

  const fetchColorPalette = useCallback(async () => {
    if (!colorQuery.trim()) {
      setError("Por favor, ingresa un color base.");
      return;
    }
    setIsLoadingColorPalette(true);
    setColorPalette(null);
    setError(null);
    const prompt = `Suggest 2-3 complementary or analogous colors for the base color "${colorQuery}". Explain briefly why they work well together or what mood they create.`;
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a color theory expert providing palette suggestions.");
      setColorPalette({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching color palette:", err);
      setError("No se pudo generar la paleta de colores. Inténtalo de nuevo.");
    } finally {
      setIsLoadingColorPalette(false);
    }
  }, [colorQuery]);
  
  useEffect(() => {
    fetchStyleTip();
  }, [fetchStyleTip]);

  return (
    <PageWrapper title="Define tu Estilo" backPath="/style">
      <div className="space-y-8">
        {error && <Card className="p-4 bg-red-700/30 border border-red-500"><p className="text-red-300 text-sm">{error}</p></Card>}

        {/* Style Tip Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-pink-400 mb-4">Consejo de Estilo del Día</h2>
          {isLoadingStyleTip && <Spinner color="text-pink-400" />}
          {styleTip && !isLoadingStyleTip && (
            <GeminiResponseDisplay text={styleTip.text} groundingMetadata={styleTip.grounding} className="text-slate-200 mb-4" />
          )}
          <Button onClick={fetchStyleTip} isLoading={isLoadingStyleTip} className="w-full md:w-auto bg-pink-500 hover:bg-pink-600">
            Nuevo Consejo de Estilo
          </Button>
        </Card>

        {/* Outfit Idea Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-pink-400 mb-4">Ideas de Atuendos</h2>
          <div className="space-y-4 mb-4">
            <Input
              Icon={SearchIcon}
              type="text"
              placeholder="Ocasión (Ej: 'cena formal', 'paseo de fin de semana')"
              value={occasionQuery}
              onChange={(e) => setOccasionQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && fetchOutfitIdea()}
            />
            <Button onClick={fetchOutfitIdea} isLoading={isLoadingOutfitIdea} className="w-full md:w-auto bg-pink-500 hover:bg-pink-600">
              Sugerir Atuendo
            </Button>
          </div>
          {isLoadingOutfitIdea && <Spinner color="text-pink-400" className="mt-4" />}
          {outfitIdea && !isLoadingOutfitIdea && (
             <GeminiResponseDisplay text={outfitIdea.text} groundingMetadata={outfitIdea.grounding} className="mt-4" />
          )}
        </Card>

        {/* Color Palette Helper Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-pink-400 mb-4">Ayudante de Paleta de Colores</h2>
          <div className="space-y-4 mb-4">
            <Input
              Icon={SearchIcon} // Or a specific color icon if available
              type="text"
              placeholder="Color base (Ej: 'azul marino', 'coral', 'verde oliva')"
              value={colorQuery}
              onChange={(e) => setColorQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && fetchColorPalette()}
            />
            <Button onClick={fetchColorPalette} isLoading={isLoadingColorPalette} className="w-full md:w-auto bg-pink-500 hover:bg-pink-600">
              Sugerir Paleta
            </Button>
          </div>
          {isLoadingColorPalette && <Spinner color="text-pink-400" className="mt-4" />}
          {colorPalette && !isLoadingColorPalette && (
            <GeminiResponseDisplay text={colorPalette.text} groundingMetadata={colorPalette.grounding} className="mt-4" />
          )}
        </Card>
      </div>
    </PageWrapper>
  );
};

export default StyleDetailsPage;