
import React from 'react';

const CubeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2.25 7.5A3.75 3.75 0 016 3.75h12A3.75 3.75 0 0121.75 7.5v9A3.75 3.75 0 0118 20.25H6A3.75 3.75 0 012.25 16.5v-9zm3.75-.75a2.25 2.25 0 00-2.25 2.25v9c0 1.24 1.01 2.25 2.25 2.25h12a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25H6z" clipRule="evenodd" />
    <path d="M6 9.75A.75.75 0 016.75 9h10.5a.75.75 0 01.75.75v4.5a.75.75 0 01-.75.75H6.75a.75.75 0 01-.75-.75v-4.5z" />
  </svg>
);
export default CubeIcon;
