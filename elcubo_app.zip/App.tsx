import React from 'react';
import { Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Section, SectionConfig } from './types';
import { SECTIONS, DEFAULT_SECTION, FLOATING_ACTION_BUTTON_COLOR } from './constants';
import SectionLandingPage from './pages/SectionLandingPage';
import NutritionDetailsPage from './pages/NutritionDetailsPage';
import FitnessDetailsPage from './pages/FitnessDetailsPage';
import EntertainmentDetailsPage from './pages/EntertainmentDetailsPage';
import WellnessDetailsPage from './pages/WellnessDetailsPage';
import TravelDetailsPage from './pages/TravelDetailsPage';
import MindDetailsPage from './pages/MindDetailsPage'; // Import MindDetailsPage
import StyleDetailsPage from './pages/StyleDetailsPage'; // Import StyleDetailsPage

import { CubeIcon } from './components/icons';

const App: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const fabAction = () => {
    const currentBaseSection = location.pathname.split('/')[1];
    if (location.pathname.includes('/details') && SECTIONS[currentBaseSection as Section]) {
       navigate(`/${currentBaseSection}`);
    } else if (SECTIONS[currentBaseSection as Section]) {
       navigate(`/${DEFAULT_SECTION}`);
    } else {
      navigate(`/${DEFAULT_SECTION}`);
    }
  };

  const showFab = location.pathname !== '/' && (location.pathname.includes("/details") || Object.values(SECTIONS).some(s => `/${s.id}` === location.pathname));


  return (
    <div className="flex flex-col min-h-screen bg-slate-900">
      <div className="flex-grow">
        <Routes>
          <Route path="/" element={<Navigate to={`/${DEFAULT_SECTION}`} replace />} />
          {Object.keys(SECTIONS).map((key) => (
            <Route
              key={key}
              path={`/${key}`}
              element={<SectionLandingPage key={key as Section} sectionKey={key as Section} />}
            />
          ))}
          <Route path="/nutrition/details" element={<NutritionDetailsPage />} />
          <Route path="/fitness/details" element={<FitnessDetailsPage />} />
          <Route path="/mind/details" element={<MindDetailsPage />} /> {/* Add route for MindDetailsPage */}
          <Route path="/entertainment/details" element={<EntertainmentDetailsPage />} />
          <Route path="/wellness/details" element={<WellnessDetailsPage />} />
          <Route path="/style/details" element={<StyleDetailsPage />} /> {/* Add route for StyleDetailsPage */}
          <Route path="/travel/details" element={<TravelDetailsPage />} />
          <Route path="*" element={<Navigate to={`/${DEFAULT_SECTION}`} replace />} />
        </Routes>
      </div>
      
      {showFab && (
        <button
          onClick={fabAction}
          aria-label="Quick Actions"
          className={`fixed bottom-6 right-6 z-50 p-4 rounded-full ${FLOATING_ACTION_BUTTON_COLOR} text-white shadow-xl transition-transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-green-600`}
        >
          <CubeIcon className="w-7 h-7" />
        </button>
      )}
    </div>
  );
};

export default App;