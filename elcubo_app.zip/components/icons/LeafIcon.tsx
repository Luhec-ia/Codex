
import React from 'react';

const LeafIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M12.963 2.286a.75.75 0 00-1.071 1.056 9.769 9.769 0 01-2.432 5.224L9 10.5H7.5A2.25 2.25 0 005.25 12.75V21a.75.75 0 00.75.75h12a.75.75 0 00.75-.75v-8.25A2.25 2.25 0 0016.5 10.5H15V9.75a2.25 2.25 0 00-2.25-2.25h-.618a.75.75 0 01-.53-.22L11.152 6.62a.75.75 0 00-1.061 0l-.972.972A7.5 7.5 0 004.5 12.75v8.25a.75.75 0 00.75.75h13.5a.75.75 0 00.75-.75V12.75a4.5 4.5 0 00-4.5-4.5h-1.5V6.375c0-1.28-.563-2.438-1.487-3.248L12.963 2.286zM6 12.75V21h12v-8.25a3 3 0 00-3-3H9a3 3 0 00-3 3z" clipRule="evenodd" />
    <path d="M8.25 6.75a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0Z" />
  </svg>
);
export default LeafIcon;
