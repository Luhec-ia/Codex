
import React from 'react';
import { GroundingMetadata, GroundingChunk } from '../types';
import { ExternalLinkIcon } from './icons'; // Assuming you have an ExternalLinkIcon

interface GeminiResponseDisplayProps {
  text: string;
  groundingMetadata?: GroundingMetadata;
  className?: string;
}

const GeminiResponseDisplay: React.FC<GeminiResponseDisplayProps> = ({ text, groundingMetadata, className }) => {
  const formatText = (rawText: string) => {
    // Basic formatting: replace \n with <br />, bold markdown **text**
    let formatted = rawText.replace(/\n/g, '<br />');
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    return { __html: formatted };
  };
  
  return (
    <div className={`p-4 bg-slate-800 rounded-lg shadow ${className}`}>
      <div 
        className="text-slate-200 prose prose-sm prose-invert max-w-none" 
        dangerouslySetInnerHTML={formatText(text)} 
      />
      {groundingMetadata && groundingMetadata.groundingChunks && groundingMetadata.groundingChunks.length > 0 && (
        <div className="mt-4 pt-3 border-t border-slate-700">
          <h4 className="text-xs font-semibold text-slate-400 mb-2">Sources:</h4>
          <ul className="list-none p-0 space-y-1">
            {groundingMetadata.groundingChunks.map((chunk: GroundingChunk, index: number) => (
              chunk.web && (
                <li key={index} className="text-xs">
                  <a 
                    href={chunk.web.uri} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-emerald-400 hover:text-emerald-300 hover:underline flex items-center"
                  >
                    {chunk.web.title || chunk.web.uri}
                    <ExternalLinkIcon className="w-3 h-3 ml-1 shrink-0" />
                  </a>
                </li>
              )
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default GeminiResponseDisplay;
