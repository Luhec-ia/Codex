
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BackArrowIcon } from '../icons';

interface PageWrapperProps {
  title: string;
  children: React.ReactNode;
  showBackButton?: boolean;
  backPath?: string; // Optional custom path for back button
}

const PageWrapper: React.FC<PageWrapperProps> = ({ title, children, showBackButton = true, backPath }) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (backPath) {
      navigate(backPath);
    } else {
      navigate(-1); // Go back to the previous page in history
    }
  };

  return (
    <div className="flex-grow flex flex-col p-4 md:p-6 bg-slate-900 text-slate-100 min-h-screen">
      <header className="mb-6 flex items-center">
        {showBackButton && (
          <button 
            onClick={handleBack}
            className="mr-4 p-2 rounded-full hover:bg-slate-700 transition-colors"
            aria-label="Go back"
          >
            <BackArrowIcon className="h-6 w-6 text-slate-300" />
          </button>
        )}
        <h1 className="text-3xl font-bold text-emerald-400 tracking-tight">{title}</h1>
      </header>
      <main className="flex-grow">
        {children}
      </main>
    </div>
  );
};

export default PageWrapper;
