
import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";
import { API_KEY, GEMINI_API_MODEL_TEXT } from '../constants';
import { GroundingMetadata } from "../types";

if (!API_KEY) {
  console.warn("API_KEY is not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" });

export const generateText = async (prompt: string, systemInstruction?: string, useGoogleSearch: boolean = false): Promise<{text: string, groundingMetadata?: GroundingMetadata}> => {
  try {
    const config: any = {};
    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }
    if (useGoogleSearch) {
      config.tools = [{googleSearch: {}}];
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_API_MODEL_TEXT,
      contents: prompt,
      config: Object.keys(config).length > 0 ? config : undefined,
    });
    
    const text = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata as GroundingMetadata | undefined;
    return { text, groundingMetadata };

  } catch (error) {
    console.error("Error generating text from Gemini:", error);
    throw error;
  }
};

export const generateJson = async <T,>(prompt: string, systemInstruction?: string): Promise<T | null> => {
  try {
    const config: any = { responseMimeType: "application/json" };
    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_API_MODEL_TEXT,
      contents: prompt,
      config: config,
    });
    
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    return JSON.parse(jsonStr) as T;

  } catch (error) {
    console.error("Error generating JSON from Gemini:", error);
    // Fallback or rethrow, depending on desired behavior
    // For now, let's return null if parsing fails or API error
    return null; 
  }
};


let chatInstance: Chat | null = null;

export const startChat = (systemInstruction?: string): Chat => {
  chatInstance = ai.chats.create({
    model: GEMINI_API_MODEL_TEXT,
    config: {
      systemInstruction: systemInstruction || "You are a helpful assistant.",
    },
  });
  return chatInstance;
};

export const sendMessageToChat = async (message: string): Promise<string> => {
  if (!chatInstance) {
    startChat(); // Initialize with default if not started
  }
  if (!chatInstance) throw new Error("Chat not initialized"); // Should not happen

  try {
    const response: GenerateContentResponse = await chatInstance.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error sending message to chat:", error);
    throw error;
  }
};

export const streamMessageToChat = async (message: string, onChunk: (chunkText: string) => void): Promise<void> => {
  if (!chatInstance) {
    startChat();
  }
  if (!chatInstance) throw new Error("Chat not initialized");

  try {
    const responseStream = await chatInstance.sendMessageStream({ message });
    for await (const chunk of responseStream) {
      onChunk(chunk.text);
    }
  } catch (error) {
    console.error("Error streaming message to chat:", error);
    throw error;
  }
};

// Placeholder for image generation if needed in the future
// import { GEMINI_API_MODEL_IMAGE } from '../constants';
// export const generateImage = async (prompt: string): Promise<string | null> => {
//   try {
//     const response = await ai.models.generateImages({
//       model: GEMINI_API_MODEL_IMAGE,
//       prompt: prompt,
//       config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
//     });
//     if (response.generatedImages && response.generatedImages.length > 0) {
//       const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
//       return `data:image/jpeg;base64,${base64ImageBytes}`;
//     }
//     return null;
//   } catch (error) {
//     console.error("Error generating image from Gemini:", error);
//     return null;
//   }
// };

