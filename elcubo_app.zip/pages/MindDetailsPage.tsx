import React, { useState, useCallback, useEffect } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Spinner from '../components/ui/Spinner';
import { generateText } from '../services/geminiService';
import { GroundingMetadata } from '../types';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';
import { SearchIcon } from '../components/icons';

const MindDetailsPage: React.FC = () => {
  const [brainTeaser, setBrainTeaser] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingBrainTeaser, setIsLoadingBrainTeaser] = useState(false);
  
  const [productivityTip, setProductivityTip] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingProductivityTip, setIsLoadingProductivityTip] = useState(false);

  const [learnQuery, setLearnQuery] = useState('');
  const [learningResource, setLearningResource] = useState<{ text: string; grounding?: GroundingMetadata } | null>(null);
  const [isLoadingLearningResource, setIsLoadingLearningResource] = useState(false);
  
  const [error, setError] = useState<string | null>(null);

  const fetchBrainTeaser = useCallback(async () => {
    setIsLoadingBrainTeaser(true);
    setBrainTeaser(null);
    setError(null);
    const prompt = "Generate a short, clever brain teaser or riddle. Make it solvable but challenging. Ensure the answer is not explicitly in the teaser itself, but can be inferred.";
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a creative riddle and brain teaser generator.");
      setBrainTeaser({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching brain teaser:", err);
      setError("No se pudo generar el acertijo. Inténtalo de nuevo.");
    } finally {
      setIsLoadingBrainTeaser(false);
    }
  }, []);

  const fetchProductivityTip = useCallback(async () => {
    setIsLoadingProductivityTip(true);
    setProductivityTip(null);
    setError(null);
    const prompt = "Generate a concise and actionable productivity tip.";
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are an expert in productivity and personal development.");
      setProductivityTip({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching productivity tip:", err);
      setError("No se pudo generar el consejo. Inténtalo de nuevo.");
    } finally {
      setIsLoadingProductivityTip(false);
    }
  }, []);

  const fetchLearningResource = useCallback(async () => {
    if (!learnQuery.trim()) {
      setError("Por favor, ingresa un tema para aprender.");
      return;
    }
    setIsLoadingLearningResource(true);
    setLearningResource(null);
    setError(null);
    const prompt = `Provide a link to a high-quality online resource (article, video, or course) to learn about "${learnQuery}". Briefly explain why it's a good resource. Use Google Search to find relevant and current resources.`;
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are an AI assistant helping users find learning materials.", true);
      setLearningResource({ text, grounding: groundingMetadata });
    } catch (err) {
      console.error("Error fetching learning resource:", err);
      setError("No se pudo encontrar el recurso de aprendizaje. Inténtalo de nuevo.");
    } finally {
      setIsLoadingLearningResource(false);
    }
  }, [learnQuery]);

  useEffect(() => {
    fetchBrainTeaser();
    fetchProductivityTip();
  }, [fetchBrainTeaser, fetchProductivityTip]);

  return (
    <PageWrapper title="Expande tu Mente" backPath="/mind">
      <div className="space-y-8">
        {error && <Card className="p-4 bg-red-700/30 border border-red-500"><p className="text-red-300 text-sm">{error}</p></Card>}

        {/* Brain Teaser Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-purple-400 mb-4">Acertijo del Día</h2>
          {isLoadingBrainTeaser && <Spinner color="text-purple-400" />}
          {brainTeaser && !isLoadingBrainTeaser && (
            <GeminiResponseDisplay text={brainTeaser.text} groundingMetadata={brainTeaser.grounding} className="text-slate-200 mb-4" />
          )}
          <Button onClick={fetchBrainTeaser} isLoading={isLoadingBrainTeaser} className="w-full md:w-auto bg-purple-500 hover:bg-purple-600">
            Nuevo Acertijo
          </Button>
        </Card>

        {/* Productivity Tip Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-purple-400 mb-4">Consejo de Productividad</h2>
          {isLoadingProductivityTip && <Spinner color="text-purple-400" />}
          {productivityTip && !isLoadingProductivityTip && (
             <GeminiResponseDisplay text={productivityTip.text} groundingMetadata={productivityTip.grounding} className="text-slate-200 mb-4" />
          )}
          <Button onClick={fetchProductivityTip} isLoading={isLoadingProductivityTip} className="w-full md:w-auto bg-purple-500 hover:bg-purple-600">
            Nuevo Consejo
          </Button>
        </Card>

        {/* Learning Resource Section */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold text-purple-400 mb-4">Aprende Algo Nuevo</h2>
          <div className="space-y-4 mb-4">
            <Input
              Icon={SearchIcon}
              type="text"
              placeholder="¿Qué quieres aprender hoy? Ej: 'Mindfulness', 'Historia del arte'"
              value={learnQuery}
              onChange={(e) => setLearnQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && fetchLearningResource()}
            />
            <Button onClick={fetchLearningResource} isLoading={isLoadingLearningResource} className="w-full md:w-auto bg-purple-500 hover:bg-purple-600">
              Buscar Recurso
            </Button>
          </div>
          {isLoadingLearningResource && <Spinner color="text-purple-400" className="mt-4" />}
          {learningResource && !isLoadingLearningResource && (
            <GeminiResponseDisplay text={learningResource.text} groundingMetadata={learningResource.grounding} className="mt-4" />
          )}
        </Card>
      </div>
    </PageWrapper>
  );
};

export default MindDetailsPage;