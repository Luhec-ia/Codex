
import React from 'react';

const AppleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M12.963 2.286a.75.75 0 00-1.071 1.056 9.769 9.769 0 01-2.432 5.224L9 10.5H7.5A2.25 2.25 0 005.25 12.75V21a.75.75 0 00.75.75h12a.75.75 0 00.75-.75v-8.25A2.25 2.25 0 0016.5 10.5H15V9.75a2.25 2.25 0 00-2.25-2.25H12.13l.543-1.085a2.25 2.25 0 00-.099-2.319l-.002-.003ZM10.5 12.75a.75.75 0 00-1.5 0v4.5a.75.75 0 001.5 0v-4.5ZM15 12.75a.75.75 0 00-1.5 0v4.5a.75.75 0 001.5 0v-4.5Z" clipRule="evenodd" />
    <path d="M8.25 6.75a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0Z" />
  </svg>
);
export default AppleIcon;
