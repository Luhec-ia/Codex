
import React, { useState, useCallback } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import { generateText, generateJson } from '../services/geminiService';
import { TravelDestination, GroundingMetadata } from '../types';
import { SearchIcon, PlusIcon, MinusIcon, SendIcon } from '../components/icons';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';

const initialDestinations: TravelDestination[] = [
  { id: 'paris', name: 'Torre Eiffel, París', description: 'Icónica torre de celosía de hierro.', imageUrl: 'https://picsum.photos/seed/eiffel/400/300' },
  { id: 'louvre', name: 'Museo del Louvre, París', description: 'El museo de arte más grande del mundo.', imageUrl: 'https://picsum.photos/seed/louvre/400/300' },
  { id: 'rome', name: 'Coliseo, Roma', description: 'Antiguo anfiteatro en el centro de Roma.', imageUrl: 'https://picsum.photos/seed/colosseum/400/300' },
];

const TravelDetailsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [destinations, setDestinations] = useState<TravelDestination[]>(initialDestinations);
  const [isLoading, setIsLoading] = useState(false);
  const [searchResult, setSearchResult] = useState<string | null>(null);
  const [searchGrounding, setSearchGrounding] = useState<GroundingMetadata | undefined>();
  const [searchError, setSearchError] = useState<string | null>(null);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) {
      setSearchError("Por favor, ingresa un destino o pregunta de viaje.");
      return;
    }
    setSearchError(null);
    setIsLoading(true);
    setSearchResult(null);
    setSearchGrounding(undefined);

    const prompt = `Provide travel information or suggestions for "${searchQuery}". Include interesting facts, tips, or a brief itinerary idea. If it's a specific place, describe it. If it's a question, answer it. Use Google Search for up-to-date information.`;
    
    try {
      const { text, groundingMetadata } = await generateText(prompt, "You are a helpful travel assistant.", true);
      setSearchResult(text);
      setSearchGrounding(groundingMetadata);

      if (text.length < 200) { 
        const suggestionPrompt = `Suggest 3 travel destinations related to or near "${searchQuery}".
        For each, provide id (string), name (string), description (string), and an imageUrl ("https://picsum.photos/seed/UNIQUE_DEST_NAME/400/300").
        Return as JSON array.`;
        const suggestedDests = await generateJson<TravelDestination[]>(suggestionPrompt);
        if (suggestedDests && suggestedDests.length > 0) {
          setDestinations(prevDests => {
            const newDests = suggestedDests.filter(sd => !prevDests.find(pd => pd.id === sd.id));
            // Add new unique suggestions to the beginning, then existing ones, limit total to e.g. 6
            const combined = [...newDests, ...prevDests.filter(pd => !newDests.find(nd => nd.id === pd.id))];
            return combined.slice(0, 6); 
          });
        }
      }

    } catch (error) {
      console.error("Error searching travel info:", error);
      setSearchError("No se pudo obtener información de viaje. Inténtalo de nuevo.");
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery]);

  const DestinationCard: React.FC<{ dest: TravelDestination }> = ({ dest }) => (
    <Card 
      className="group" 
      hoverEffect 
      onClick={() => {
        setSearchQuery(dest.name);
        // Optionally trigger search immediately: handleSearch(); 
        // For now, just sets the query, user can click search button
      }}
    >
      <img src={dest.imageUrl} alt={dest.name} className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105" />
      <div className="p-4">
        <h3 className="font-semibold text-lg text-indigo-300 mb-1">{dest.name}</h3>
        <p className="text-slate-300 text-sm">{dest.description}</p>
      </div>
    </Card>
  );

  return (
    <PageWrapper title="Detalles de Viaje" backPath="/travel"> 
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input
            Icon={SearchIcon}
            type="text"
            placeholder="¿A dónde quieres ir? o haz una pregunta..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="flex-grow"
          />
          <Button onClick={handleSearch} isLoading={isLoading} className="w-full sm:w-auto bg-indigo-500 hover:bg-indigo-600">
            Buscar
          </Button>
        </div>
        {searchError && <p className="text-sm text-red-400 -mt-2 mb-2">{searchError}</p>}

        {/* Map Placeholder and Controls */}
        <Card className="p-4 relative aspect-[16/10] md:aspect-[16/7] bg-slate-800">
          <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/worldmap/1200/600')] bg-cover bg-center opacity-30 blur-sm"></div>
          <div className="relative z-10 flex items-center justify-center h-full">
            <p className="text-slate-400 text-xl font-semibold">Visualización de Mapa (Placeholder)</p>
          </div>
          <div className="absolute bottom-4 right-4 z-10 flex flex-col space-y-2">
            <Button variant="secondary" size="sm" className="p-2 aspect-square !rounded-full"><PlusIcon className="w-5 h-5" /></Button>
            <Button variant="secondary" size="sm" className="p-2 aspect-square !rounded-full"><MinusIcon className="w-5 h-5" /></Button>
            <Button variant="secondary" size="sm" className="p-2 aspect-square !rounded-full"><SendIcon className="w-5 h-5" /></Button>
          </div>
        </Card>
        
        {isLoading && <Spinner className="my-6" />}

        {searchResult && !isLoading && (
          <section className="mt-6">
            <h2 className="text-2xl font-semibold text-indigo-400 mb-3">Información para: {searchQuery}</h2>
            <GeminiResponseDisplay text={searchResult} groundingMetadata={searchGrounding} />
          </section>
        )}

        {(!searchResult || destinations.length > 0) && !isLoading && ( // Show popular destinations if no search result OR if there are destinations to show
          <section className="mt-6">
            <h2 className="text-2xl font-semibold text-indigo-400 mb-4">
              {searchResult ? 'Destinos Relacionados' : 'Destinos Populares'}
            </h2>
            {destinations.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {destinations.map(dest => <DestinationCard key={dest.id} dest={dest} />)}
              </div>
            ) : (
              !searchResult && <p className="text-slate-400">No hay destinos populares para mostrar en este momento.</p>
            )}
          </section>
        )}
      </div>
    </PageWrapper>
  );
};

export default TravelDetailsPage;
