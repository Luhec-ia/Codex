
import React, { useState, useEffect, useCallback } from 'react';
import PageWrapper from '../components/layout/PageWrapper';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import { generateJson, generateText } from '../services/geminiService';
import { Game, GroundingMetadata } from '../types';
import { SearchIcon } from '../components/icons';
import GeminiResponseDisplay from '../components/GeminiResponseDisplay';

const initialMiniGames: Game[] = [
  { id: 'game1', name: 'Cube Runner', imageUrl: 'https://picsum.photos/seed/controller1/300/200' },
  { id: 'game2', name: 'Galaxy Invaders', imageUrl: 'https://picsum.photos/seed/controller2/300/200' },
  { id: 'game3', name: 'Pixel Jumper', imageUrl: 'https://picsum.photos/seed/controller3/300/200' },
  { id: 'game4', name: 'Astro Miner', imageUrl: 'https://picsum.photos/seed/controller4/300/200' },
];

const initialUpcomingReleases: Game[] = [
  { id: 'upcoming1', name: 'CyberSphere X', description: 'A new AAA RPG.', imageUrl: 'https://picsum.photos/seed/upcoming1/400/250' },
  { id: 'upcoming2', name: 'Neon Racer 2077', description: 'Futuristic racing.', imageUrl: 'https://picsum.photos/seed/upcoming2/400/250' },
];

const EntertainmentDetailsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [miniGames, setMiniGames] = useState<Game[]>(initialMiniGames);
  const [upcomingReleases, setUpcomingReleases] = useState<Game[]>(initialUpcomingReleases);
  const [searchResults, setSearchResults] = useState<Game[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searchGrounding, setSearchGrounding] = useState<GroundingMetadata | undefined>();

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) {
      setSearchError("Por favor, ingresa un término de búsqueda.");
      setSearchResults(null); // Clear previous results if search is empty
      return;
    }
    setSearchError(null);
    setIsLoading(true);
    setSearchResults(null);
    setSearchGrounding(undefined);

    const prompt = `Find or suggest mini-games related to "${searchQuery}". 
    Provide up to 3 results. For each game, include id (string), name (string), and an imageUrl ("https://picsum.photos/seed/UNIQUE_SEARCH_RESULT_NAME/300/200").
    Return as a JSON array of game objects. If no specific games are found, suggest creative game ideas based on the query.`;

    try {
      const results = await generateJson<Game[]>(prompt, "You are a game recommendation engine.");
      setSearchResults(results && results.length > 0 ? results : []);
      
      // Fetch related info with Google Search
      const { groundingMetadata } = await generateText(`Find news or information about games related to "${searchQuery}"`, undefined, true);
      setSearchGrounding(groundingMetadata);

    } catch (error) {
      console.error("Error searching games:", error);
      setSearchError("No se pudieron encontrar juegos. Inténtalo de nuevo.");
      setSearchResults([]); // Set to empty array on error to indicate search was performed
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery]);

  // Optional: Fetch dynamic games on load
  // useEffect(() => { /* fetch initial games */ }, []);

  const GameCard: React.FC<{ game: Game, large?: boolean }> = ({ game, large = false }) => (
    <Card className="group" hoverEffect>
      <img src={game.imageUrl} alt={game.name} className={`w-full ${large ? 'h-56' : 'h-40'} object-cover transition-transform duration-300 group-hover:scale-105`} />
      <div className="p-4">
        <h3 className={`font-semibold ${large ? 'text-xl' : 'text-lg'} text-rose-300 mb-1`}>{game.name}</h3>
        {game.description && <p className="text-slate-300 text-sm">{game.description}</p>}
      </div>
    </Card>
  );

  return (
    <PageWrapper title="Centro de Entretenimiento" backPath="/entertainment">
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input
            Icon={SearchIcon}
            type="text"
            placeholder="Buscar juegos o géneros..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="flex-grow"
          />
          <Button onClick={handleSearch} isLoading={isLoading} className="w-full sm:w-auto">
            Buscar
          </Button>
        </div>
        {searchError && <p className="text-sm text-red-400 -mt-4 mb-4">{searchError}</p>}
        {isLoading && <Spinner className="my-6" />}

        {searchResults !== null && (
          <section>
            <h2 className="text-2xl font-semibold text-rose-400 mb-4">Resultados de Búsqueda</h2>
            {searchResults.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchResults.map(game => <GameCard key={game.id} game={game} />)}
              </div>
            ) : (
              <p className="text-slate-400">No se encontraron juegos para "{searchQuery}". ¿Quizás probar otra búsqueda?</p>
            )}
            {searchGrounding && (
               <div className="mt-4">
                 <GeminiResponseDisplay text="" groundingMetadata={searchGrounding} />
               </div>
            )}
          </section>
        )}

        {searchResults === null && ( // Only show default sections if no search has been made or search is cleared
          <>
            <section>
              <h2 className="text-2xl font-semibold text-rose-400 mb-4">Mini Juegos</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {miniGames.map(game => <GameCard key={game.id} game={game} />)}
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-rose-400 mb-4">Próximos Lanzamientos</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {upcomingReleases.map(game => <GameCard key={game.id} game={game} large />)}
              </div>
            </section>
          </>
        )}
      </div>
    </PageWrapper>
  );
};

export default EntertainmentDetailsPage;
