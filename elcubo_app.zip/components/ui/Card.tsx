
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  hoverEffect?: boolean;
}

const Card: React.FC<CardProps> = ({ children, className = '', onClick, hoverEffect = false }) => {
  const baseStyles = "bg-slate-800/70 backdrop-blur-sm shadow-xl rounded-xl overflow-hidden";
  const hoverStyles = hoverEffect ? "transition-all duration-200 ease-in-out hover:shadow-2xl hover:scale-[1.02] hover:bg-slate-700/80" : "";
  const clickableStyles = onClick ? "cursor-pointer" : "";

  return (
    <div
      className={`${baseStyles} ${hoverStyles} ${clickableStyles} ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

export default Card;
