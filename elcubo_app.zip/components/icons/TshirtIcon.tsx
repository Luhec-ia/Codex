
import React from 'react';

const TshirtIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v11.25C1.5 17.16 2.34 18 3.375 18H9.75v1.5H6.625a.75.75 0 000 1.5h10.75a.75.75 0 000-1.5H14.25v-1.5h6.375c1.035 0 1.875-.84 1.875-1.875V4.875C22.5 3.839 21.66 3 20.625 3H3.375z" />
    <path fillRule="evenodd" d="M12 12.75a.75.75 0 00.75-.75V6.317c0-.987-.487-1.874-1.29-2.433A3.752 3.752 0 0012 3.75a3.752 3.752 0 00-.46.134c-.804.56-1.29 1.446-1.29 2.433v5.683a.75.75 0 00.75.75h1.5z" clipRule="evenodd" />
  </svg>
);
export default TshirtIcon;
