
import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Section, SectionConfig } from '../types';
import { SECTIONS } from '../constants';
import Button from '../components/ui/Button';

interface SectionLandingPageProps {
  sectionKey: Section;
}

const SectionLandingPage: React.FC<SectionLandingPageProps> = ({ sectionKey }) => {
  const navigate = useNavigate();
  const currentSectionConfig = SECTIONS[sectionKey];
  const { name, Icon, description, themeColor, detailPath } = currentSectionConfig;

  const NavIcon: React.FC<{ config: SectionConfig; isActive: boolean }> = ({ config, isActive }) => (
    <button
      onClick={() => navigate(`/${config.id}`)}
      aria-label={config.name}
      className={`
        p-2.5 md:p-3 rounded-full transition-all duration-300 ease-in-out
        ${isActive 
          ? `bg-emerald-500/20 shadow-[0_0_15px_3px_rgba(52,211,153,0.4)] ring-2 ring-emerald-400` 
          : 'hover:bg-slate-700/50'
        }
      `}
    >
      <config.Icon className={`w-6 h-6 md:w-7 md:h-7 ${isActive ? themeColor : 'text-slate-400 hover:text-slate-200'}`} />
    </button>
  );

  return (
    <div 
        className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 relative overflow-hidden"
        // Attempting a subtle geometric pattern with pseudo-elements (complex with Tailwind only)
        // For simplicity, a rich gradient is used. A true pattern like in cubo app.jpg might need SVG background.
    >
      {/* Subtle background pattern attempt using gradients. A real image/SVG would be better for the diamond pattern. */}
      <div className="absolute inset-0 opacity-5 z-0">
        {/* Could place SVG pattern here if available */}
      </div>

      {/* Top Navigation Icons */}
      <nav className="absolute top-6 md:top-8 left-1/2 -translate-x-1/2 w-full max-w-md md:max-w-lg px-4 z-30"> {/* Changed z-10 to z-30 */}
        <div className="flex justify-around items-center bg-slate-800/50 backdrop-blur-md p-2 rounded-full shadow-lg">
          {Object.values(SECTIONS).map(config => (
            <NavIcon key={config.id} config={config} isActive={config.id === sectionKey} />
          ))}
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex flex-col items-center justify-center flex-grow z-10 pt-24 pb-12 md:pt-32">
        <div 
          className={`
            relative w-48 h-48 md:w-60 md:h-60 mb-6 md:mb-8 rounded-3xl
            flex items-center justify-center
            bg-gradient-to-br from-emerald-700/20 via-emerald-600/30 to-emerald-700/20
            border border-emerald-500/30
            shadow-[0_0_40px_10px_rgba(52,211,153,0.2),inset_0_0_20px_rgba(52,211,153,0.1)]
          `}
          style={{animation: 'pulseGlow 3s infinite alternate'}}
        >
          <Icon className={`w-24 h-24 md:w-32 md:h-32 ${themeColor} opacity-90`} />
           <style>{`
            @keyframes pulseGlow {
              0% { box-shadow: 0 0 30px 8px rgba(52,211,153,0.15), inset 0 0 15px rgba(52,211,153,0.05); }
              100% { box-shadow: 0 0 50px 12px rgba(52,211,153,0.3), inset 0 0 25px rgba(52,211,153,0.15); }
            }
          `}</style>
        </div>
        
        <h1 className={`text-4xl md:text-5xl font-bold ${themeColor} mb-3 md:mb-4 tracking-tight`}>
          {name}
        </h1>
        <p className="text-slate-300 max-w-md text-base md:text-lg leading-relaxed">
          {description}
        </p>

        {detailPath && (
          <Link to={detailPath} className="mt-8 md:mt-10">
            <Button variant="primary" size="lg" className="bg-emerald-500 hover:bg-emerald-600 shadow-lg shadow-emerald-500/30 hover:shadow-emerald-600/40 transform hover:scale-105">
              Explorar {name}
            </Button>
          </Link>
        )}
      </main>
    </div>
  );
};

export default SectionLandingPage;
