
export enum Section {
  Nutrition = "nutrition",
  Fitness = "fitness",
  Mind = "mind",
  Entertainment = "entertainment",
  Wellness = "wellness",
  Style = "style", // Added based on T-shirt icon
  Travel = "travel", // Added Travel section
}

export interface SectionConfig {
  id: Section;
  name: string;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  description: string;
  themeColor: string; // Tailwind color class e.g. emerald-500
  darkThemeColor: string; // e.g. emerald-700
  detailPath?: string;
}

export interface Recipe {
  name: string;
  description: string;
  ingredients: string[];
  instructions: string;
  imageUrl?: string; 
}

export interface WorkoutRoutine {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  category: string;
}

export interface Game {
  id: string;
  name: string;
  description?: string;
  imageUrl: string;
}

export interface WellnessActivity {
  id: string;
  name: string;
  description: string;
  duration?: string;
  imageUrl: string;
}

export interface TravelDestination {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}
export interface GroundingChunk {
  web: GroundingChunkWeb;
}
export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
}