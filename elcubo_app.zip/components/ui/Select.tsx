
import React from 'react';
import { ChevronDownIcon } from '../icons';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string | number; label: string }[];
  // Fix: Add placeholder to SelectProps interface
  placeholder?: string;
}

// Fix: Destructure placeholder and value explicitly. Use restHTMLProps for other attributes.
const Select: React.FC<SelectProps> = ({ 
  label, 
  name, 
  error, 
  options, 
  className, 
  placeholder, 
  value, 
  ...restHTMLProps 
}) => {
  
  // Determine if the placeholder should be considered active for styling.
  // This is true if a placeholder string is provided and the select's current value implies the placeholder is shown
  // (i.e., value is undefined, or an empty string).
  const isPlaceholderEffectivelySelected = !!placeholder && (value === undefined || value === "");

  return (
    <div className="w-full">
      {label && (
        <label htmlFor={name} className="block text-sm font-medium text-slate-300 mb-1">
          {label}
        </label>
      )}
      <div className="relative">
        <select
          id={name}
          name={name}
          className={`
            block w-full appearance-none px-3 py-2.5 rounded-lg 
            bg-slate-700/50 border border-slate-600 
            ${/* Fix: Apply placeholder text color conditionally, remove incorrect 'placeholder-slate-400' class */''}
            ${isPlaceholderEffectivelySelected ? 'text-slate-400' : 'text-slate-100'}
            focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 
            sm:text-sm
            ${error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''}
            ${className}
          `}
          value={value} // Explicitly pass the value prop to the select element
          {...restHTMLProps} // Spread remaining HTML attributes
        >
          {/* Fix: Use the destructured 'placeholder' variable. Error was likely on this line (originally line 33). */}
          {placeholder && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map(option => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-400">
          <ChevronDownIcon className="h-5 w-5" />
        </div>
      </div>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
};

export default Select;
