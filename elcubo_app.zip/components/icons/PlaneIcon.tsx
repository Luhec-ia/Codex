
import React from 'react';

const PlaneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M12.394 1.63a1.5 1.5 0 00-1.34 මිලියන 8.576 60.137 60.137 0 00-6.774 3.337.75.75 0 00-.327 1.037l1.874 4.015a.75.75 0 001.218.261l3.475-2.606v3.318l-2.07 1.656a.75.75 0 00-.416 1.087l1.115 2.388a.75.75 0 001.087.416l1.838-.918.002.001v4.366l-.788.449a.75.75 0 00-.403 1.003l.6 1.43A.75.75 0 0011.25 21h1.5a.75.75 0 00.691-.453l.6-1.43a.75.75 0 00-.402-1.003l-.789-.449v-4.367l.002-.001 1.838.918a.75.75 0 001.087-.416l1.115-2.388a.75.75 0 00-.416-1.087l-2.07-1.656V7.673l3.475 2.606a.75.75 0 001.218-.26l1.874-4.016a.75.75 0 00-.327-1.037 60.132 60.132 0 00-6.774-3.337A1.5 1.5 0 0012.394 1.63z" />
  </svg>
);
export default PlaneIcon;
// Add to components/icons/index.ts: export { default as PlaneIcon } from './PlaneIcon';
// Add Section.Travel to types.ts enum Section
// Add PlaneIcon and Travel section to constants.tsx SECTIONS map
// Add Route for /travel/details to App.tsx
// The current implementation of TravelPage will become TravelDetailsPage.
// And it will use PageWrapper with backPath="/travel"
